



import {Component} from '@angular/core';
import {Event} from '../models/event' ;

import { EventService }  from "../services/events.service";

@Component({
    selector:"event-list",
    templateUrl:'app/events/views/events.list.component.html',
    providers :[EventService]
})
export class EventListComponent{
    title:string = "Events List";
    searchBy : string ="";
    selectedEvent:Event;
    thankYouNote:string;
   // event:Event;
    events:Event[]=[
    ];
    constructor(private eventsService :EventService){
        //this.event=new Event(1, 'JQTRN', 'jquery seminar', 'seminar on jquery 3 new features', new Date(), new Date(),200, 45, 'images/jquery.png')
    }

    noOnInit():void{
        this.events=this.eventsService.getAllEvents();
    }

    ShowEventDetails(event:Event): void{
        this.selectedEvent=event;
    }
    receivedThankyouNote(note : string) :void{        
        this.thankYouNote=note;
    }
} 