import { Component, OnInit } from '@angular/core';

@Component({
    selector: 'events-menu',
    templateUrl: 'app/navigation/views/events-menu.component.html'
})

export class EventHeader implements OnInit {
    constructor() { }

    ngOnInit() { }
}